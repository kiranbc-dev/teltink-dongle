package Parser.View;

import de.saxsys.mvvmfx.ViewModel;

public class ParserViewModel implements ViewModel {

}
